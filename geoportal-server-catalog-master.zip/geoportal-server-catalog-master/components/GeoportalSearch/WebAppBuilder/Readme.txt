Please refer to the following url on how to use the widgets:
https://github.com/Esri/geoportal-server-catalog/wiki/Configure-Widgets