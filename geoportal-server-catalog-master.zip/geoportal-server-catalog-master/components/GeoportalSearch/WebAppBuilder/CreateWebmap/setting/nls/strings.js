define({
	root: ({
		configText: "Set config text:"
  })
});
