The "Webmap to OGC Conversion" widget will read in the webmap defined by the "webmap" url var and output a geoJSON OGC context file (with more formats to come).

The user is also able to include feature layers added using the "Add Data" widget as well by using the checkbox.
