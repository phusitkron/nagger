﻿define({
    root:({
		description: "Use this tool to read a json-encoded OGC Context document.",
		ok: "OK",
		cancel: "Cancel",
		tabOpenFile: "Open",
		tabSaveAsFile: "SaveAs",
		addFile: "Select Context Document",
		saveAsFile: "Save as Context Document",
		ows_geojson: "GeoJSON",
		ows_atom: "ATOM",
		ows_context: "Web Map Context"
    }) 
});
