This is the GeoportalSearch widget for ArcGIS Web AppBuilder.
