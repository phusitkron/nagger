define({
  root: {
    add: "Add Catalog",
    url: "Url",
    title: "Title",
    actions: "Actions",
	invalidUrl: 'Url is invalid.',
	getCatalogs: "Get Catalogs",
	geoportalCatalog: "Type in a federated Geoportal catalog url",
	addCatalog: "Add Catalog",
	or: "Or",
	recordsPerPage: "Number of records per page"
  }
});