define({
  root: ({

    _widgetLabel: "Geoportal Search"

  })
});
